package com.sb.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sb.dao.memberDao;
import com.sb.dto.memberDto;

@RunWith(SpringJUnit4ClassRunner.class) // -> 이 테스트는 스프링과 함께 실행하겠다. 라고 스프링에게 알림
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/root-context.xml" })
public class memberDaoTest {
	// 회원추가 
	@Autowired
	memberDao mDao;
	@Test
	public void testInsertMember () throws Exception {
		//Given
		String id = "test1"; 
		String pw = "12";
		String name = "12";
		//When
		mDao.insertMember(id, pw, name);
		//Then
		assertEquals(id,"test1");
	}
	//가입한 회원조회
	@Test
	public void testSelectMember() throws Exception {
		//Given
		String id = "test1";
		String pw = "12";
		//When
		memberDto dto = mDao.selectMember(id, pw);
		//Then
		System.out.println(dto.getId());
	}
	//전체회원조회
	@Test
	public void testSelectMemberList() throws Exception {
		//Given
		//When
		List<memberDto> list1 = mDao.selectMemberList();
		//Then
		for( memberDto dto : list1 ) {
			System.out.println(dto.getId() + dto.getName() + dto.getPoint());
		}
	}
	//회원삭제
	@Test
	public void testDeleteMember() throws Exception {
		//Given
		String id = "test2";
		//When
		mDao.deleteMember(id);
		//Then
		assertEquals(id,"test2");
	}
	//수정할 회원 조회
	@Test
	public void testSelectMemberForUpdate() throws Exception {
		//Given
		String id = "YG";
		//When
		memberDto dto = mDao.selectMemberForUpdate(id);
		//Then
		System.out.println(dto.getId());
	}
	//멤버수정하기
	@Test
	public void testUpdateMember() throws Exception {
		//Given
		String id = "test";
		String pw = "1234";
		String name = "1234";
		int point = 1000;
		//When
		mDao.updateMember(id, pw, name, point);
		//Then
	}
}
