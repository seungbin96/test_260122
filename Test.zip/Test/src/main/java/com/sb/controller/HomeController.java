package com.sb.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sb.dto.memberDto;
import com.sb.service.memberService;
import com.sb.service.schedulerService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	@Autowired
	memberService mSvc;
	
	@RequestMapping("/")
	public String home() {
		
		return "login";
	}
	@RequestMapping("/createForm")
	public String createForm() {
		
		return "create";
	}
	@RequestMapping("/create")
	public String create(@RequestParam("id") String id,
						@RequestParam("pw") String pw,
						@RequestParam("name") String name) {
		mSvc.addMember(id, pw, name);
		return "redirect:/login";
	}
	@RequestMapping("/login")
	public String Login() {
		
		return "login";
	}
	@RequestMapping("/loginCheck")
	public String loginCheck(@RequestParam("id") String id,
							@RequestParam("pw") String pw, 
							HttpSession session, 
							RedirectAttributes rttr,
							Model model) {
		
		memberDto dto = mSvc.getMember(id, pw);
		if(dto != null && id.equals(dto.getId()) && pw.equals(dto.getPw())) {
			session.setAttribute("loginId", id); // 세션값에 로그인아이디 저장 
			if(id.equals("admin")) { // 아이디가 관리자와 같으면 관리자페이지로 이동 
				return "redirect:/mainAdmin";
			}else {
				
				return "redirect:/main";
			}
		}
		else {
			rttr.addFlashAttribute("msg","fail");
			return "redirect:/login";
		}
	}
					
	@RequestMapping("/main")
	public String main(HttpSession session, Model model) {
		String loginId = (String)session.getAttribute("loginId");
		memberDto mDto = mSvc.getMemberForUpdate(loginId);
		model.addAttribute("mDto", mDto);
		if(loginId == null) {
			return "redirect:/login";
		}else {
		return "main";
		}
	}
	@RequestMapping("/mainAdmin")
	public String mainAdmin(Model model, HttpSession session) {
		List<memberDto> memberList = mSvc.getAllMemberList();
		String loginId = (String)session.getAttribute("loginId");
		
		if(loginId == null || !loginId.equals("admin")) {
			return "redirect:/login";
		}
		model.addAttribute("memberList", memberList);
		return "mainAdmin";
	}
	@RequestMapping("/modifyMember")
	public String modifyMember(@RequestParam("id") String id, Model model) {
		memberDto dto = mSvc.getMemberForUpdate(id);
		model.addAttribute("dto", dto);
		return "modifyMember";
	}
	@RequestMapping("/deleteMember")
	public String deleteMemeber(@RequestParam("id") String id) {
		mSvc.deleteMember(id);
		return "redirect:/mainAdmin";
	}
	@RequestMapping("/modifyAction")
	public String modifyAction(@RequestParam("id") String id,
								@RequestParam("pw") String pw,
								@RequestParam("name") String name,
								@RequestParam("point") int point,
								RedirectAttributes rttr) {
		
		mSvc.modifyMemberInfo(id, pw, name, point);
		rttr.addFlashAttribute("msg2", "success");
		return "redirect:/mainAdmin";
	}
	// 스케줄러
	@Autowired
	schedulerService sSvc;
	@RequestMapping("/start")
	public String start() {
		try {
//			logger.info("스케줄러 시작");
			sSvc.startScheduler();
		}
		catch(Exception e ) {
			e.printStackTrace();
		}
		return "redirect:/mainAdmin";
	}
	@RequestMapping("/end")
	public String end() {
		try {
//			logger.info("스케줄러 종료");
			sSvc.endScheduler();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return "redirect:/mainAdmin";
	}
	@RequestMapping("/bannerAction")
	public String bannerAction(String item, int point, HttpSession session,
								RedirectAttributes rttr,Model model) {
		
		String loginId = (String)session.getAttribute("loginId");
		int myPoint = mSvc.selectPoint(loginId);
		if(myPoint < point) {
	        rttr.addFlashAttribute("msg", "less");
	    } else {
	        mSvc.minusPoint(loginId, point); 
	        
	        rttr.addFlashAttribute("msg", "ok");
	        rttr.addFlashAttribute("item", item);
	    }
	    return "redirect:/main";
	}
	@RequestMapping("/footerAction")
	public String footerAction(HttpSession session, RedirectAttributes rttr) {
		String loginId = (String) session.getAttribute("loginId");
	    
	    // 1. 1~1000 사이 난수 생성
	    int randomPoint = (int)(Math.random() * 1000) + 1;
	    
	    // 2. DB 업데이트 (포인트 증가)
	    mSvc.plusPoint(loginId, randomPoint);
	    
	    // 3. 메시지 전달 (얼럿용)
	    rttr.addFlashAttribute("msg", "plus");
	    rttr.addFlashAttribute("point", randomPoint);
		return "redirect:/main";
	}
	
}
