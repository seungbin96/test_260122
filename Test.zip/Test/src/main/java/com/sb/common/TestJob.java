package com.sb.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.sb.service.memberService;

public class TestJob implements Job {
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        
		Object obj = context.getJobDetail().getJobDataMap().get("mSvc");
		memberService mSvc = (memberService) obj;
		
		if (mSvc != null) {
	        // 서비스 메서드에 int 파라미터가 있으니 1을 전달합니다.
	        mSvc.updatePoint(1); 
	        
	        System.out.println("[" + now + "] 스케줄러: 모든 회원에게 포인트 1점을 지급했습니다.");
	    }
        
	}

}
