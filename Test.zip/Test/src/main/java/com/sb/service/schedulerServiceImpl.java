package com.sb.service;

import java.util.HashSet;
import java.util.Set;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sb.common.TestJob;


@Service
public class schedulerServiceImpl implements schedulerService {
	private Scheduler s = null;
	@Autowired
	memberService mSvc;
	@Override
	public void startScheduler() throws Exception {
		SchedulerFactory sf = new StdSchedulerFactory();
		s = sf.getScheduler();
		
		JobDataMap map = new JobDataMap();
	    map.put("mSvc", mSvc);
	    
	    // 2. JobDetail 설정 시 .setJobData()를 사용합니다.
	    JobDetail jobDetail = JobBuilder.newJob(TestJob.class)
	                                .setJobData(map) 
	                                .build();
		
		CronTrigger trigger = (CronTrigger)TriggerBuilder.newTrigger()
						.withSchedule(CronScheduleBuilder.cronSchedule("*/20 * * * * ?")) // 2초마다 실행 
						.forJob(jobDetail)
						.build();
		Set<Trigger> set1 = new HashSet<>();
		set1.add(trigger);
		
		s.scheduleJob(jobDetail, set1, false);
		s.start();
		
	}

	@Override
	public void endScheduler() throws Exception {
		s.shutdown();
		
	}

}
