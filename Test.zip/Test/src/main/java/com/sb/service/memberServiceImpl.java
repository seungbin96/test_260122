package com.sb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sb.dao.memberDao;
import com.sb.dto.memberDto;

@Service
public class memberServiceImpl implements memberService{
	@Autowired
	memberDao mDao;
	@Override
	@Transactional
	public void addMember(String id, String pw, String name) {
		mDao.insertMember(id, pw, name);
	}
	@Override
	public memberDto getMember(String id, String pw) {
		return mDao.selectMember(id, pw);
	}
	@Override
	public List<memberDto> getAllMemberList() {
		return mDao.selectMemberList();
	}
	@Override
	public void deleteMember(String id) {
		mDao.deleteMember(id);
	}
	@Override
	public memberDto getMemberForUpdate(String id) {
		return mDao.selectMemberForUpdate(id);
	}
	@Override
	public void modifyMemberInfo(String id, String pw, String name, int point) {
		mDao.updateMember(id, pw, name, point);
	}
	@Override
	public void updatePoint(int point) {
		mDao.updatePoint(point);
	}
	@Override
	public int selectPoint(String id) {
		return mDao.selectPoint(id);
	}
	@Override
	public void minusPoint(String id, int point) {
		mDao.minusPoint(id, point);
	}
	@Override
	public void plusPoint(String id, int point) {
		mDao.plusPoint(id, point);
	}
}
