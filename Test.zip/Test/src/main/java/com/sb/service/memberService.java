package com.sb.service;

import java.util.List;

import com.sb.dto.memberDto;

public interface memberService {
	void addMember(String id , String pw, String name);
	memberDto getMember(String id, String pw);
	List<memberDto> getAllMemberList();
	void deleteMember(String id);
	memberDto getMemberForUpdate(String id);
	void modifyMemberInfo(String id, String pw, String name, int point);
	void updatePoint(int point);
	int selectPoint(String id);
	void minusPoint (String id, int point);
	void plusPoint (String id, int point);
}
