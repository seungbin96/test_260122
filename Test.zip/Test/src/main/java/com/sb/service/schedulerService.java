package com.sb.service;

public interface schedulerService {
	void startScheduler() throws Exception; // 스케줄러 시작 
	void endScheduler() throws Exception; // 스케줄러 종료 
}
