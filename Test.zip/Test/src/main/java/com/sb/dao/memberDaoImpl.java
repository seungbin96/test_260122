package com.sb.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sb.dto.memberDto;

@Repository
public class memberDaoImpl implements memberDao {

	@Autowired
	SqlSession session;
	@Override
	public void insertMember(String id, String pw, String name) {
		Map<String, Object> map1 = new HashMap<>();
		map1.put("id", id);
		map1.put("pw", pw);
		map1.put("name", name);
		session.insert("memberMapper.insertMember", map1);
	}
	@Override
	public memberDto selectMember(String id, String pw) {
		Map<String, Object> map1 = new HashMap<>();
		map1.put("id", id);
		map1.put("pw", pw);
		return session.selectOne("memberMapper.selectMember",map1);
	}
	@Override
	public List<memberDto> selectMemberList() {
		return session.selectList("memberMapper.selectMemberList");
	}
	@Override
	public void deleteMember(String id) {
		session.delete("memberMapper.deleteMember", id);
	}
	@Override
	public memberDto selectMemberForUpdate(String id) {
		return session.selectOne("memberMapper.selectMemberForUpdate", id);
	}
	@Override
	public void updateMember(String id, String pw, String name, int point) {
		Map<String, Object> map1 = new HashMap<>();
		map1.put("id", id);
		map1.put("pw", pw);
		map1.put("name", name);
		map1.put("point", point);
		session.update("memberMapper.updateMember", map1);
	}
	@Override
	public void updatePoint(int point) {
		session.update("memberMapper.updatePoint", point);
	}
	@Override
	public int selectPoint(String id) {
		return session.selectOne("memberMapper.selectPoint",id);
	}
	@Override
	public void minusPoint(String id, int point) {
		Map<String, Object> map1 = new HashMap<>();
		map1.put("id", id);
		map1.put("point", point);
		session.update("memberMapper.minusPoint", map1);
	}
	@Override
	public void plusPoint(String id, int point) {
		Map<String, Object> map1 = new HashMap<>();
		map1.put("id", id);
		map1.put("point", point);
		session.update("memberMapper.plusPoint", map1);
	}
}
