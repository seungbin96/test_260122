package com.sb.dao;

import java.util.List;

import com.sb.dto.memberDto;

public interface memberDao {
	void insertMember(String id, String pw, String name);
	memberDto selectMember(String id, String pw);
	List<memberDto> selectMemberList();
	void deleteMember(String id);
	memberDto selectMemberForUpdate(String id);
	void updateMember (String id, String pw, String name, int point);
	void updatePoint (int point);
	int selectPoint(String id);
	void minusPoint(String id, int point);
	void plusPoint(String id, int point);
}
